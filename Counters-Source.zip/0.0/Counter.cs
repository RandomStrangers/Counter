﻿class Counter
{
    static System.UInt64 x;
    const System.String Version = "0.0.0.0";
    const System.String Name = "Seth Conley";
    static void Main(string[] args)
    {
        System.Console.Title = "Test" + " v" + Version + " By " + Name;
        while (x != System.UInt64.MaxValue)
        {
            x++;
            System.Console.WriteLine("UInt64:" + x);
        }
    }
}