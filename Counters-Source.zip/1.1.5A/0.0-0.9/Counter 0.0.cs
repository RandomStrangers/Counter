﻿public class Counter_0_0
{
    public static System.UInt64 x;
    public const System.String Version = "0.0.0.0";
    public const System.String Name = "Seth Conley";
    public static void Main()
    {
        //System.Console.Title = "Test" + " v" + Version + " By " + Name;
        while (x != System.UInt64.MaxValue)
        {
            x++;
            System.Console.WriteLine("UInt64:" + x);
        }
    }
}