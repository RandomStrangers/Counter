﻿using System.Reflection;

[assembly: AssemblyTitle("Counter")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("Counter")]
[assembly: AssemblyCompany(Counter.Maker)]
[assembly: AssemblyVersion(Counter.InternalVersion)]