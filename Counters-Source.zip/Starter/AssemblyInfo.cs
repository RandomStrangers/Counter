﻿using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("Starter")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("Starter v" + Starter.InternalVersion)]
[assembly: AssemblyVersion(Starter.InternalVersion)]
[assembly: AssemblyCompany("Harmony")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2011")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(true)]
[assembly: Guid("FAE04EC0-301F-11D3-BF4B-00C04F79EFBC")]
[assembly: AssemblyFileVersion(Starter.InternalVersion)]
